package com.meera.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AboutScreen(onBack: () -> Unit) {
    SubScreen("About Meera AI", onBack) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Avatar(110.dp)
            Text("Meera AI  v2.2.0", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
            Text("Meera ek AI companion hai, insaan nahi. Woh galtiyan kar sakti hai - zaroori cheezein khud check karo.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SectionTitle("New in 2.2: Meera Aura")
        Text(
            "✨ Meera sunti / sochti / bolti hai to screen ke kinaron par premium glow border. Bolte waqt border awaaz ke saath pulse karti hai.\n" +
                "✨ Mode: Off / Sirf app me / Poore phone par (har app ke upar; \"Display over other apps\" permission aapko khud deni hoti hai).\n" +
                "✨ Live call me asli awaaz ke volume se pulse; phone ki TTS awaaz me volume nahi milta, wahan natural pulse chalti hai.",
            fontSize = 13.sp
        )
        SectionTitle("New in 2.1: Meera Eyes")
        Text(
            "👀 \"Meera open your eyes\" / \"aankhein kholo\" / \"camera on\" (band: \"close your eyes\" / \"aankhein band karo\" / \"camera off\") - chat, call aur Live call me\n" +
                "👀 Camera sirf tumhari command par chalta hai, kabhi apne aap nahi. Frames sirf Gemini ko jate hain jab tak eyes ON hon; kuch save ya record nahi hota.\n" +
                "👀 HUD: objects par Iron-Man jaise brackets + label (HUMAN, DOG, TREE...). Insaan par sirf \"HUMAN\" - naam/pehchaan/umar/jazbaat nahi.\n" +
                "👀 \"Ye kya hai?\" poochho: Meera poori jaankari deti hai (awaaz + text card).\n" +
                "👀 Auto-close: 5 minute (Settings me badal sakte ho), app background me jaane par, garmi/low battery par.",
            fontSize = 13.sp
        )
        SectionTitle("Implemented")
        Text(
            "✅ Gemini chat (model list Google se refresh hoti hai)\n" +
                "✅ Web search (Google grounding) in Chat\n" +
                "✅ Calling mode: Gemini Live API + fallback (recognizer + TTS)\n" +
                "✅ Intents: apps, YouTube, music, browser, maps, camera, settings, alarm, timer, calendar, dial, SMS\n" +
                "✅ Accessibility: read screen, tap, scroll, back/home (opt-in)\n" +
                "✅ Notification reading (opt-in) + summary\n" +
                "✅ Coding mode with copy / save file\n" +
                "✅ Memory (view/edit/delete/clear), summaries\n" +
                "✅ OCR, image Q&A, PDF summary, translate, study, writing, planner, voice notes\n" +
                "✅ WhatsApp / SMS by number or contact name (confirmation first, optional auto-Send)\n" +
                "✅ Memory & actions are confirmed by talking (haan / nahi), no popups\n" +
                "✅ Avatar with 8 expressions (chat mood tag, call states)\n" +
                "✅ Quick-access notification",
            fontSize = 13.sp
        )
        SectionTitle("Not implemented (honest list)")
        Text(
            "❌ Custom wake-word (needs always-on mic + battery)\n" +
                "❌ Floating bubble overlay\n" +
                "❌ Screen capture (MediaProjection)\n" +
                "❌ Auto-calling (dialer opens, you press Call)\n" +
                "⚠ Live API protocol/model names change often - agar Live fail ho to Settings mein model refresh karo; fallback apne aap chalta hai.",
            fontSize = 13.sp
        )
    }
}
