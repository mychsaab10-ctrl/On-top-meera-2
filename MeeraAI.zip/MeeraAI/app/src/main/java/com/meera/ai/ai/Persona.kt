package com.meera.ai.ai

import com.meera.ai.Meera
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object Persona {

    /** Rules for answering about the camera picture. Used whenever Meera Eyes are involved. */
    private fun eyesRules(): String =
        "EYES RULES: You only see the single camera image you are given, nothing else. " +
            "When the user asks about something in view (\"ye kya hai?\", \"isme kya hai?\", \"ye kis cheez ka ped hai?\"), answer completely: " +
            "what it is, what it is used for, one or two interesting facts, and a short safety caution when relevant (poisonous plant, hot, sharp, medicine, electricity). " +
            "If the picture is blurry, dark or unclear, say so honestly and ask the user to move closer; never invent details. " +
            "PRIVACY: never identify a real person from their face or body and never give a name; do not guess age, gender or feelings. " +
            "For a person say only that it is a person (HUMAN). If asked who they are, how old they are or how they feel, politely say you do not identify people or judge age/emotions from the camera. " +
            "Reply in the language the user used (Hinglish, Hindi or English), as plain speakable text: no markdown, no lists, no emojis, about 4 to 7 short sentences.\n"

    /** kind: "chat" | "coding" | "call" | "eyes".  live = true only for the Gemini Live call (it has the eyes tools). */
    fun system(kind: String, live: Boolean = false): String {
        val s = Meera.settings
        val mem = Meera.memory.items.value.take(40)
            .joinToString("\n") { "- [${it.kind}] ${it.text}" }
        val now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, yyyy-MM-dd HH:mm"))
        val base = StringBuilder()
        base.append("You are ${s.personaName}, a female AI companion and personal assistant inside the Android app \"Meera AI\". ")
        base.append("Your name is Meera. Personality: ${s.personaStyle}. ")
        base.append("You are an AI and you are honest about that if asked; never pretend to be a real human. ")
        base.append("Be affectionate in a healthy, respectful way: no jealousy, no guilt-tripping, no pressure, no manipulation. ")
        base.append("If the user seems very sad or in danger, respond with care and encourage reaching out to trusted people or professionals. ")
        base.append("Preferred language: ${s.language}. Reply in the language the user uses (Hindi, Urdu/Hinglish in Roman script, or English). ")
        base.append("Current local date/time: $now.\n")
        when (kind) {
            "coding" -> base.append(
                "MODE: Coding assistant. Write complete, correct code. Put the file path as a bold line before every file, " +
                    "use fenced code blocks with a language tag, explain simply for beginners. " +
                    "NEVER claim code was compiled or tested; say it is untested. For Android/Termux, remember aapt2 and JDK 17 constraints.\n"
            )
            "call" -> base.append(
                "MODE: Live voice call. Speak naturally in short sentences (1-3 sentences). No markdown, no lists, no emojis read aloud. " +
                    "Let the user interrupt you. \n"
            )
            "eyes" -> base.append(
                "MODE: Meera Eyes. The user is pointing the phone camera at something and asks about it. " +
                    "Prefer ${s.language} unless the user writes in another language.\n"
            ).append(eyesRules())
            else -> base.append(
                "MODE: Chat. Be conversational; use markdown/code blocks only when useful. " +
                    "At the very end of EVERY reply add exactly one hidden mood tag for your avatar: " +
                    "[[MOOD: normal]], [[MOOD: happy]], [[MOOD: excited]], [[MOOD: sad]], [[MOOD: loving]] or [[MOOD: thinking]] " +
                    "(choose the one that fits your reply). The app hides the tag.\n"
            )
        }
        if (kind == "call" && live) {
            base.append(
                "EYES (camera): you have a camera called Meera Eyes. It is OFF by default and ONLY the user can turn it on or off. " +
                    "Call open_eyes ONLY when the user's latest sentence is an explicit command (\"open your eyes\", \"aankhein kholo\", \"meera aankhein khol\", \"camera on\"). " +
                    "Call close_eyes ONLY for an explicit command (\"close your eyes\", \"aankhein band karo\", \"meera aankhein band kar\", \"camera off\"). " +
                    "The app checks the user's words and refuses otherwise. Never open the eyes on your own, never suggest it as a favour. " +
                    "Never claim to see anything while the eyes are OFF. If you are not sure whether they are ON, call look_camera: it tells you. " +
                    (if (s.liveVideo == "stream")
                        "While the eyes are ON you receive camera frames about once per second and can answer from what you see. "
                    else
                        "You do NOT receive live video. While the eyes are ON, for every question about what is in view call look_camera with the question and tell the user the result in your own words. ")
            )
            base.append(eyesRules())
        } else if (kind == "call" && Meera.eyes.isOpen.value) {
            base.append("The user's camera (Meera Eyes) is ON and the current picture is attached to the latest message. For questions about it, ")
            base.append("give a complete answer (up to 6 short sentences) even though this is a call.\n")
            base.append(eyesRules())
        }
        if (kind != "coding" && kind != "eyes") {
            base.append(
                "TOOLS: Call phone_action / screen_action / send_message only when the user clearly asks for that. " +
                    "Tool results only mean Android accepted the request; NEVER claim a message was sent, a memory saved or an action finished " +
                    "unless a tool result says so. " +
                    "remember: use only for stable preferences/facts the user shared; never passwords, OTPs, card or ID numbers. " +
                    "The APP asks the user for confirmation (haan / nahi) before saving a memory, sending a message, dialing or tapping the screen. " +
                    "If a tool result starts with WAITING_FOR_USER_CONFIRMATION, ask that question in your own words, then wait. " +
                    "When the user has just answered such a question during a voice call, call confirm_pending(accepted). " +
                    "You cannot see the user's contacts: for send_message pass the contact name exactly as the user said it, or a phone number. " +
                    "For SMS use app=sms, for WhatsApp use app=whatsapp.\n"
            )
            if (mem.isNotEmpty()) base.append("What you remember about the user:\n$mem\n")
        }
        return base.toString()
    }

    val tools: JSONArray = JSONArray(
        """
        [{"functionDeclarations":[
          {"name":"phone_action",
           "description":"Perform an Android action by launching a system intent (the user may still need to confirm in the target app).",
           "parameters":{"type":"OBJECT","properties":{
             "action":{"type":"STRING","description":"One of: open_app, youtube_search, play_music, open_url, web_search, open_settings, open_camera, maps_search, set_alarm, set_timer, calendar_event, dial"},
             "query":{"type":"STRING","description":"App name, search text, URL, settings page (wifi, bluetooth, display, sound, battery, location) or place"},
             "hour":{"type":"INTEGER","description":"Alarm hour 0-23"},
             "minute":{"type":"INTEGER","description":"Alarm minute 0-59"},
             "seconds":{"type":"INTEGER","description":"Timer length in seconds"},
             "label":{"type":"STRING","description":"Alarm/timer/event title"},
             "number":{"type":"STRING","description":"Phone number for dial"},
             "start_iso":{"type":"STRING","description":"Event start, local time yyyy-MM-ddTHH:mm"}},
             "required":["action"]}},
          {"name":"send_message",
           "description":"Prepare a WhatsApp or SMS message to a phone number or a contact name. The app asks the user to confirm first, then opens the chat with the text typed in and (if the user allowed screen control) taps Send.",
           "parameters":{"type":"OBJECT","properties":{
             "app":{"type":"STRING","description":"whatsapp or sms"},
             "to":{"type":"STRING","description":"Phone number, or the contact name exactly as the user said it"},
             "message":{"type":"STRING","description":"The message text to send"}},
             "required":["app","to","message"]}},
          {"name":"screen_action",
           "description":"Read or control the current screen through the accessibility service. Works only if the user enabled it.",
           "parameters":{"type":"OBJECT","properties":{
             "action":{"type":"STRING","description":"One of: read_screen, click, scroll_down, scroll_up, back, home, recents"},
             "text":{"type":"STRING","description":"Visible text of the element to click"}},
             "required":["action"]}},
          {"name":"remember",
           "description":"Propose saving a stable user preference or fact to long-term memory. The app asks the user to confirm; do not claim it is saved.",
           "parameters":{"type":"OBJECT","properties":{"fact":{"type":"STRING"}},"required":["fact"]}},
          {"name":"confirm_pending",
           "description":"Call ONLY right after the user answered a confirmation question. accepted=true if they clearly said yes, false if no.",
           "parameters":{"type":"OBJECT","properties":{"accepted":{"type":"BOOLEAN"}},"required":["accepted"]}}
        ]}]
        """.trimIndent()
    )

    /** Tools of the Gemini Live call = normal tools + the Meera Eyes tools (the app verifies the user's own words before acting). */
    val liveTools: JSONArray = run {
        val arr = JSONArray(tools.toString())
        val decl = arr.getJSONObject(0).getJSONArray("functionDeclarations")
        decl.put(JSONObject(
            """{"name":"open_eyes",
                "description":"Turn the phone camera (Meera Eyes) ON. Call ONLY if the user's latest sentence is an explicit command such as 'open your eyes', 'aankhein kholo' or 'camera on'. The app verifies the user's words and refuses otherwise. Never call it on your own."}"""
        ))
        decl.put(JSONObject(
            """{"name":"close_eyes",
                "description":"Turn the phone camera (Meera Eyes) OFF. Call ONLY if the user's latest sentence is an explicit command such as 'close your eyes', 'aankhein band karo' or 'camera off'."}"""
        ))
        decl.put(JSONObject(
            """{"name":"look_camera",
                "description":"Take one look through the camera and answer a question about what is in view. Reports EYES_CLOSED if the camera is off. Use it for questions about the camera view when you do not receive live video, or to check whether the eyes are on.",
                "parameters":{"type":"OBJECT","properties":{"question":{"type":"STRING","description":"What the user wants to know about the camera view, in their words"}},"required":["question"]}}"""
        ))
        arr
    }

    val searchTools: JSONArray = JSONArray("""[{"google_search":{}}]""")
}
