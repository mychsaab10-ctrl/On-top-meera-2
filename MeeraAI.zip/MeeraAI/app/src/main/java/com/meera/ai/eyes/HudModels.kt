package com.meera.ai.eyes

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Normalized (0..1) box in the UPRIGHT camera frame. category: human, animal, plant, vehicle, food, object, other. */
data class HudBox(
    val id: Long,
    val label: String,
    val category: String,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val seenAt: Long,
    val stale: Boolean = false
)

/** One detection as parsed from Gemini (before it is matched to an existing on-screen box). */
class Detection(val label: String, val category: String, val left: Float, val top: Float, val right: Float, val bottom: Float)

class ScanResult(val summary: String, val objects: List<Detection>)

/** Turns Gemini's JSON answer into safe, validated detections. Anything odd is dropped, never crashes. */
object HudParser {
    val categories = setOf("human", "animal", "plant", "vehicle", "food", "object", "other")
    const val MAX_OBJECTS = 8

    fun parse(raw: String): ScanResult? {
        var s = raw.trim()
        if (s.startsWith("```")) s = s.removePrefix("```json").removePrefix("```JSON").removePrefix("```").removeSuffix("```").trim()
        val root: JSONObject = try {
            if (s.startsWith("[")) {
                JSONObject().put("objects", JSONArray(s))
            } else {
                val a = s.indexOf('{')
                val b = s.lastIndexOf('}')
                if (a < 0 || b <= a) return null
                JSONObject(s.substring(a, b + 1))
            }
        } catch (e: JSONException) {
            return null
        }
        val summary = root.optString("summary").trim().take(160)
        val arr = root.optJSONArray("objects") ?: JSONArray()
        val out = ArrayList<Detection>()
        for (i in 0 until arr.length()) {
            if (out.size >= MAX_OBJECTS) break
            val o = arr.optJSONObject(i) ?: continue
            val box = o.optJSONArray("box_2d") ?: continue
            if (box.length() < 4) continue
            // Gemini format: [ymin, xmin, ymax, xmax], each 0..1000
            val ymin = (box.optDouble(0, -1.0) / 1000.0).toFloat().coerceIn(0f, 1f)
            val xmin = (box.optDouble(1, -1.0) / 1000.0).toFloat().coerceIn(0f, 1f)
            val ymax = (box.optDouble(2, -1.0) / 1000.0).toFloat().coerceIn(0f, 1f)
            val xmax = (box.optDouble(3, -1.0) / 1000.0).toFloat().coerceIn(0f, 1f)
            if (xmax - xmin < 0.02f || ymax - ymin < 0.02f) continue
            var cat = o.optString("category").trim().lowercase()
            if (cat !in categories) cat = "other"
            // PRIVACY: a person is only ever labelled HUMAN - never a name, never age/mood, whatever the model wrote.
            val label = if (cat == "human") "HUMAN" else
                o.optString("label").trim().uppercase().replace(Regex("[^\\p{L}\\p{N} \\-]"), "").take(18).ifBlank { cat.uppercase() }
            if (label == "PERSON" || label == "MAN" || label == "WOMAN" || label == "BOY" || label == "GIRL" || label == "CHILD") {
                out.add(Detection("HUMAN", "human", xmin, ymin, xmax, ymax))
            } else {
                out.add(Detection(label, cat, xmin, ymin, xmax, ymax))
            }
        }
        return ScanResult(summary, out)
    }
}
